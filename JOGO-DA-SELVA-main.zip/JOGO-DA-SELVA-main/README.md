# JOGO-DA-SELVA
Jogo criado utilizando Python e a biblioteca do PgZero.
O jogo é simples e funciona da seguinte forma: Ao iniciar o game você será um personagem que pode pular e andar para os lados e pisar em cima dos inimigos.
